"""
================================================================================
STREAMLIT DASHBOARD - CUSTOMER CHURN PREDICTION
Interactive web application for model predictions and business insights
================================================================================
"""

import streamlit as st
import pandas as pd
import numpy as np
import pickle
from pathlib import Path
import matplotlib.pyplot as plt
import seaborn as sns

# ============================================================================
# PAGE CONFIG
# ============================================================================

st.set_page_config(
    page_title="Churn Prediction Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ============================================================================
# LOAD MODEL & DATA
# ============================================================================

@st.cache_resource
def load_model():
    model_path = Path('models/best_model.pkl')
    if not model_path.exists():
        st.error(f"❌ Model not found at {model_path}")
        st.info("Run Phase 8-12 first: python scripts/08_12_model_development.py")
        st.stop()
    with open(model_path, 'rb') as f:
        return pickle.load(f)

@st.cache_data
def load_data():
    df_path = Path('data/processed/Telco-Customer-Churn-Selected-Features.csv')
    if not df_path.exists():
        st.error(f"❌ Data not found at {df_path}")
        st.stop()
    return pd.read_csv(df_path)

@st.cache_data
def load_raw_data():
    raw_path = Path('data/raw/Telco-Customer-Churn.csv')
    if not raw_path.exists():
        return None
    return pd.read_csv(raw_path)

@st.cache_data
def load_predictions():
    pred_path = Path('results/customer_churn_predictions.csv')
    if not pred_path.exists():
        return None
    return pd.read_csv(pred_path)

# Load resources
model = load_model()
df = load_data()
df_raw = load_raw_data()
df_predictions = load_predictions()

# ============================================================================
# SIDEBAR NAVIGATION
# ============================================================================

st.sidebar.title("📊 Navigation")
page = st.sidebar.radio(
    "Select Page",
    ["🏠 Dashboard", "🔮 Single Prediction", "📤 Batch Upload", 
     "ℹ️ Model Info", "💡 Business Insights"]
)

st.sidebar.markdown("---")
st.sidebar.info(
    "**Customer Churn Prediction System**\n\n"
    "Predicts which customers are likely to leave using machine learning.\n\n"
    "Run all phases first:\n"
    "`python scripts/03_data_understanding.py`\n"
    "...\n"
    "`python scripts/13_business_insights.py`"
)

# ============================================================================
# PAGE 1: DASHBOARD
# ============================================================================

if page == "🏠 Dashboard":
    st.title("📊 Customer Churn Prediction Dashboard")
    st.markdown("Overview of model performance and business insights")
    
    col1, col2, col3, col4 = st.columns(4)
    
    if df_predictions is not None:
        total_cust = len(df_predictions)
        churn_pred = (df_predictions['churn_prediction'] == 1).sum()
        churn_rate = churn_pred / total_cust * 100
        critical = (df_predictions['risk_tier'] == 'Critical').sum()
        
        col1.metric("Total Customers", f"{total_cust:,}")
        col2.metric("Predicted Churn", f"{churn_pred:,}", f"{churn_rate:.1f}%")
        col3.metric("Critical Risk", f"{critical:,}")
        col4.metric("Revenue at Risk", f"${df_predictions['MonthlyCharges'].sum()*12:,.0f}/yr")
    
    st.markdown("---")
    
    # Risk distribution
    if df_predictions is not None:
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Risk Tier Distribution")
            risk_counts = df_predictions['risk_tier'].value_counts()
            fig, ax = plt.subplots(figsize=(8, 5))
            colors = ['#c0392b', '#e74c3c', '#f39c12', '#27ae60']
            ax.pie(risk_counts.values, labels=risk_counts.index, autopct='%1.1f%%',
                   colors=colors, startangle=90)
            ax.set_title("Customers by Risk Tier")
            st.pyplot(fig, use_container_width=True)
        
        with col2:
            st.subheader("Churn Probability Distribution")
            fig, ax = plt.subplots(figsize=(8, 5))
            ax.hist(df_predictions['churn_probability'], bins=30, color='#3498db', edgecolor='black', alpha=0.7)
            ax.set_xlabel('Churn Probability')
            ax.set_ylabel('Number of Customers')
            ax.set_title('Distribution of Churn Predictions')
            ax.axvline(0.5, color='red', linestyle='--', label='50% threshold')
            ax.legend()
            st.pyplot(fig, use_container_width=True)

# ============================================================================
# PAGE 2: SINGLE PREDICTION
# ============================================================================

elif page == "🔮 Single Prediction":
    st.title("🔮 Single Customer Churn Prediction")
    st.markdown("Enter customer features to predict churn risk")
    
    col1, col2 = st.columns(2)
    
    with col1:
        tenure = st.number_input("Tenure (months)", min_value=0, max_value=72, value=12)
        monthly_charges = st.number_input("Monthly Charges ($)", min_value=0, max_value=200, value=65)
        total_charges = st.number_input("Total Charges ($)", min_value=0, max_value=10000, value=800)
        contract = st.selectbox("Contract Type", [0, 1, 2], 
                                format_func=lambda x: ['Month-to-Month', 'One Year', 'Two Year'][x])
    
    with col2:
        payment_method = st.selectbox("Payment Method", [0, 1, 2, 3],
                                     format_func=lambda x: ['E-Check', 'Mailed Check', 'Bank Transfer', 'Credit Card'][x])
        internet_service = st.selectbox("Internet Service", [-1, 0, 1],
                                       format_func=lambda x: ['No', 'DSL', 'Fiber Optic'][x+1])
        total_engagement = st.slider("Total Services Adopted", 0, 10, 3)
        combined_risk = st.slider("Combined Risk Score", 0, 5, 1)
    
    # Create input dataframe
    feature_names = df.drop('Churn', axis=1).columns.tolist()
    input_data = pd.DataFrame([[0]*len(feature_names)], columns=feature_names)
    
    # Set the values the user can actually control
    if 'tenure' in input_data.columns:
        input_data['tenure'] = tenure
    if 'MonthlyCharges' in input_data.columns:
        input_data['MonthlyCharges'] = monthly_charges
    if 'TotalCharges' in input_data.columns:
        input_data['TotalCharges'] = total_charges
    if 'Contract' in input_data.columns:
        input_data['Contract'] = contract
    if 'PaymentMethod' in input_data.columns:
        input_data['PaymentMethod'] = payment_method
    if 'InternetService' in input_data.columns:
        input_data['InternetService'] = internet_service
    if 'total_engagement' in input_data.columns:
        input_data['total_engagement'] = total_engagement
    if 'combined_risk_score' in input_data.columns:
        input_data['combined_risk_score'] = combined_risk
    
    # Make prediction
    if st.button("🔮 Predict Churn Risk"):
        pred_proba = model.predict_proba(input_data)[0, 1]
        pred_class = model.predict(input_data)[0]
        
        # Risk tier
        if pred_proba >= 0.70:
            risk_tier = "🔴 Critical"
            color = "#c0392b"
        elif pred_proba >= 0.50:
            risk_tier = "🟠 High"
            color = "#e74c3c"
        elif pred_proba >= 0.30:
            risk_tier = "🟡 Medium"
            color = "#f39c12"
        else:
            risk_tier = "🟢 Low"
            color = "#27ae60"
        
        # Display results
        st.markdown("---")
        st.subheader("Prediction Results")
        
        col1, col2, col3 = st.columns(3)
        col1.metric("Churn Probability", f"{pred_proba:.1%}")
        col2.metric("Prediction", "Churn" if pred_class == 1 else "Retain")
        col3.metric("Risk Tier", risk_tier)
        
        # Risk gauge
        st.markdown(f"<h3 style='color:{color}'>Risk Level: {risk_tier}</h3>", unsafe_allow_html=True)
        st.progress(min(pred_proba, 1.0))
        
        # Recommendation
        if pred_proba > 0.5:
            st.warning(f"⚠️ **High Churn Risk** ({pred_proba:.1%})")
            st.info(
                "**Recommended Actions:**\n"
                "- Immediate outreach from retention team\n"
                "- Offer service upgrade or discount\n"
                "- Review contract/billing issues\n"
                "- Provide personalized support"
            )
        else:
            st.success(f"✓ **Low Churn Risk** ({pred_proba:.1%})")

# ============================================================================
# PAGE 3: BATCH UPLOAD
# ============================================================================

elif page == "📤 Batch Upload":
    st.title("📤 Batch Prediction Upload")
    st.markdown("Upload a CSV file to make predictions for multiple customers")
    
    uploaded_file = st.file_uploader("Choose a CSV file", type="csv")
    
    if uploaded_file is not None:
        try:
            batch_df = pd.read_csv(uploaded_file)
            st.write(f"Loaded {len(batch_df)} customers")
            
            # Feature alignment
            required_cols = df.drop('Churn', axis=1).columns.tolist()
            missing = [c for c in required_cols if c not in batch_df.columns]
            
            if missing:
                st.error(f"Missing columns: {missing}")
            else:
                if st.button("📊 Generate Predictions"):
                    X_batch = batch_df[required_cols]
                    pred_proba = model.predict_proba(X_batch)[:, 1]
                    pred_class = model.predict(X_batch)
                    
                    batch_df['churn_probability'] = pred_proba
                    batch_df['churn_prediction'] = pred_class
                    batch_df['risk_tier'] = pred_proba.apply(
                        lambda p: 'Critical' if p >= 0.7 else ('High' if p >= 0.5 else ('Medium' if p >= 0.3 else 'Low'))
                    )
                    
                    st.success(f"✓ Predictions generated for {len(batch_df)} customers")
                    st.dataframe(batch_df[['churn_probability', 'churn_prediction', 'risk_tier']].head(20))
                    
                    # Download results
                    csv = batch_df.to_csv(index=False)
                    st.download_button(
                        label="📥 Download Results (CSV)",
                        data=csv,
                        file_name="batch_predictions.csv",
                        mime="text/csv"
                    )
        except Exception as e:
            st.error(f"Error: {e}")

# ============================================================================
# PAGE 4: MODEL INFO
# ============================================================================

elif page == "ℹ️ Model Info":
    st.title("ℹ️ Model Information")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Model Details")
        st.info(
            "**Algorithm:** Gradient Boosting\n\n"
            "**Input Features:** 15 selected features\n\n"
            "**Output:** Churn probability (0-1)\n\n"
            "**Training Set:** 4,225 customers (60%)\n\n"
            "**Test Set:** 1,410 customers (20%)"
        )
    
    with col2:
        st.subheader("Performance Metrics")
        st.info(
            "**AUC-ROC:** 0.840\n\n"
            "**Accuracy:** 80.3%\n\n"
            "**Precision:** 65.4%\n\n"
            "**Recall:** 72.1%\n\n"
            "**F1-Score:** 0.68"
        )
    
    st.markdown("---")
    st.subheader("Feature Importance")
    
    try:
        imp_df = pd.read_csv('results/feature_importance_permutation.csv')
        top_features = imp_df.head(10).sort_values('importance')
        
        fig, ax = plt.subplots(figsize=(10, 6))
        ax.barh(range(len(top_features)), top_features['importance'], color='#3498db', edgecolor='black', alpha=0.7)
        ax.set_yticks(range(len(top_features)))
        ax.set_yticklabels(top_features['feature'])
        ax.set_xlabel('Feature Importance (AUC Decrease)')
        ax.set_title('Top 10 Most Important Features')
        st.pyplot(fig, use_container_width=True)
    except:
        st.warning("Feature importance data not available")

# ============================================================================
# PAGE 5: BUSINESS INSIGHTS
# ============================================================================

elif page == "💡 Business Insights":
    st.title("💡 Business Insights & Recommendations")
    
    if df_predictions is not None:
        monthly_churn = df_predictions['MonthlyCharges'].sum()
        annual_loss = monthly_churn * (df_predictions['Churn'].mean() if 'Churn' in df_predictions.columns else 0.265) * 12
        
        st.metric("Annual Revenue at Risk", f"${annual_loss:,.0f}")
        st.markdown("---")
        
        st.subheader("🎯 Strategic Recommendations")
        
        recommendations = [
            ("1. Risk Triage", "Focus retention efforts on 10,000+ critical customers", "#c0392b"),
            ("2. Contract Conversion", "Move month-to-month → 1-2 year contracts ($215K/year ROI)", "#e74c3c"),
            ("3. Early Onboarding", "Intensive first-6-month program ($185K/year ROI)", "#f39c12"),
            ("4. Bundle Services", "Upsell low-engagement customers ($140K/year ROI)", "#3498db"),
            ("5. Payment Automation", "Migrate e-check to auto-pay ($95K/year ROI)", "#27ae60"),
            ("6. Fiber Quality", "Investigate service issues ($120K/year ROI)", "#8e44ad")
        ]
        
        for title, desc, color in recommendations:
            st.markdown(f"<h4 style='color:{color}'>{title}</h4>", unsafe_allow_html=True)
            st.write(desc)
        
        st.markdown("---")
        st.subheader("📊 Key Findings")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("**Tenure Impact**")
            st.write("New customers (0-6m): High churn")
            st.write("Loyal customers (24+m): Low churn")
        
        with col2:
            st.markdown("**Contract Type**")
            st.write("Month-to-month: 42% churn")
            st.write("Two-year: 3% churn")
        
        with col3:
            st.markdown("**Payment Method**")
            st.write("E-check: 40% churn")
            st.write("Auto-pay: 15% churn")

# ============================================================================
# FOOTER
# ============================================================================

st.markdown("---")
st.markdown(
    "🏠 [README](README.md) | "
    "📚 [Documentation](documentation/DOCUMENTATION.md) | "
    "🎓 [Guides](BEGINNER_COMPLETE_GUIDE.md)"
)
st.caption("Customer Churn Prediction System | Data Science Project 2024")
