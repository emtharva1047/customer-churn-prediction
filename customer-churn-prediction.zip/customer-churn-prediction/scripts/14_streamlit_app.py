import pickle
from pathlib import Path

import pandas as pd
import streamlit as st

st.set_page_config(
    page_title="Customer Churn Prediction",
    page_icon="📊",
    layout="wide"
)

MODEL_PATH = Path("models/best_model.pkl")
DATA_PATH = Path("data/processed/Telco-Customer-Churn-Selected-Features.csv")

if not MODEL_PATH.exists():
    st.error("Model not found.")
    st.stop()

if not DATA_PATH.exists():
    st.error("Processed dataset not found.")
    st.stop()

with open(MODEL_PATH, "rb") as f:
    model = pickle.load(f)

df = pd.read_csv(DATA_PATH)

if "Churn" in df.columns:
    feature_names = df.drop(columns=["Churn"]).columns.tolist()
else:
    feature_names = df.columns.tolist()

st.title("📊 Customer Churn Prediction")

st.markdown(
    "Predict whether a telecom customer is likely to churn using the trained Machine Learning model."
)

left, right = st.columns([1, 1])

user_input = {}

with left:
    st.header("Customer Details")

    for col in feature_names:

        series = df[col]

        if pd.api.types.is_numeric_dtype(series):

            minimum = float(series.min())
            maximum = float(series.max())
            default = float(series.median())

            user_input[col] = st.number_input(
                col,
                min_value=minimum,
                max_value=maximum,
                value=default
            )

        else:

            options = sorted(series.dropna().unique().tolist())

            user_input[col] = st.selectbox(
                col,
                options
            )

input_df = pd.DataFrame([user_input])

if st.button("Predict Churn", use_container_width=True):

    try:

        probability = model.predict_proba(input_df)[0][1]
        prediction = model.predict(input_df)[0]

        if probability >= 0.70:
            risk = "🔴 Critical"
            color = "red"
        elif probability >= 0.50:
            risk = "🟠 High"
            color = "orange"
        elif probability >= 0.30:
            risk = "🟡 Medium"
            color = "gold"
        else:
            risk = "🟢 Low"
            color = "green"

        with right:

            st.header("Prediction")

            st.metric(
                "Churn Probability",
                f"{probability*100:.2f}%"
            )

            st.metric(
                "Prediction",
                "Yes" if prediction == 1 else "No"
            )

            st.markdown(
                f"### Risk Tier: :{color}[{risk}]"
            )

            st.progress(float(probability))

            st.subheader("Recommended Action")

            if probability >= 0.70:
                st.error(
                    "Immediate customer retention campaign required."
                )

            elif probability >= 0.50:
                st.warning(
                    "Offer discounts or loyalty benefits."
                )

            elif probability >= 0.30:
                st.info(
                    "Monitor customer activity."
                )

            else:
                st.success(
                    "Customer is unlikely to churn."
                )

            st.subheader("Input Summary")

            st.dataframe(input_df, use_container_width=True)

    except Exception as e:

        st.exception(e)