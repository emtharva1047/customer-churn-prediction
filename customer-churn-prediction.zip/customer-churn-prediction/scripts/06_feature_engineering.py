"""
================================================================================
PHASE 6: FEATURE ENGINEERING
Customer Churn Prediction Project
================================================================================
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
from scipy import stats

# ============================================================================
# CONFIGURATION — ALL PATHS
# ============================================================================

DATA_CLEANED     = Path('data/processed/Telco-Customer-Churn-Cleaned.csv')
DATA_ENGINEERED  = Path('data/processed/Telco-Customer-Churn-Engineered.csv')
FEAT_DOC_PATH    = Path('data/processed/engineered_features_documentation.csv')
FEAT_IMP_PATH    = Path('data/processed/engineered_features_importance.csv')
FIGURES_DIR      = Path('figures')
REPORTS_DIR      = Path('reports')
REPORT_PATH      = REPORTS_DIR / '06_feature_engineering_summary.txt'
FIGURE_PATH      = FIGURES_DIR / '06_engineered_features_importance.png'

Path('data/processed').mkdir(parents=True, exist_ok=True)
FIGURES_DIR.mkdir(parents=True, exist_ok=True)
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

try:
    plt.style.use('seaborn-v0_8-darkgrid')
except:
    plt.style.use('ggplot')

print("=" * 70)
print("PHASE 6: FEATURE ENGINEERING")
print("=" * 70)

# ============================================================================
# LOAD DATA
# ============================================================================

print("\n[STEP 1] Loading Cleaned Dataset...")
if not DATA_CLEANED.exists():
    raise FileNotFoundError(
        f"✗ Not found: {DATA_CLEANED}\n"
        "  Run Phase 4 first: python scripts/04_data_cleaning.py"
    )
df = pd.read_csv(DATA_CLEANED)
original_cols = df.columns.tolist()
print(f"✓ Loaded: {df.shape[0]:,} rows × {df.shape[1]} columns")

# ============================================================================
# CATEGORY 1: LIFECYCLE STAGE
# ============================================================================

print("\n[STEP 2] Creating Lifecycle Features...")

def lifecycle_stage(tenure):
    if tenure <= 6:   return 0   # New
    elif tenure <= 12: return 1  # Growth
    elif tenure <= 24: return 2  # Mature
    else:              return 3  # Loyal

df['lifecycle_stage']    = df['tenure'].apply(lifecycle_stage)
df['is_new_customer']    = (df['tenure'] <= 6).astype(int)
df['is_loyal_customer']  = (df['tenure'] > 24).astype(int)
df['is_critical_early']  = (df['tenure'] <= 6).astype(int)  # highest risk window
print("  ✓ lifecycle_stage (0=New, 1=Growth, 2=Mature, 3=Loyal)")
print("  ✓ is_new_customer, is_loyal_customer, is_critical_early")

# ============================================================================
# CATEGORY 2: CUSTOMER VALUE (CLV)
# ============================================================================

print("\n[STEP 3] Creating Customer Value Features...")

max_total = df['TotalCharges'].max()
max_monthly = df['MonthlyCharges'].max()
df['clv_score']       = (df['TotalCharges'] / max_total * 100).round(2)
df['monthly_value']   = (df['MonthlyCharges'] / max_monthly * 100).round(2)
df['clv_percentile']  = pd.qcut(df['TotalCharges'], q=4, labels=[0,1,2,3], duplicates='drop').astype(int)
print("  ✓ clv_score (0-100 normalized total charges)")
print("  ✓ monthly_value (0-100 normalized monthly charges)")
print("  ✓ clv_percentile (0=lowest, 3=highest value quartile)")

# ============================================================================
# CATEGORY 3: SERVICE ENGAGEMENT
# ============================================================================

print("\n[STEP 4] Creating Engagement Features...")

addon_cols = ['OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
              'TechSupport', 'StreamingTV', 'StreamingMovies']

# Count services (only for internet customers, -1 means no internet)
df['total_services_raw']     = df[addon_cols].apply(lambda r: (r == 1).sum(), axis=1)
df['has_internet']           = (df['InternetService'] != -1).astype(int)
df['has_phone']              = (df['PhoneService'] == 1).astype(int)
df['total_engagement']       = df['total_services_raw'] + df['has_internet'] + df['has_phone']
df['tech_engagement']        = df[['OnlineSecurity','TechSupport']].apply(
                                   lambda r: (r == 1).sum(), axis=1)
df['entertainment_engagement'] = df[['StreamingTV','StreamingMovies']].apply(
                                   lambda r: (r == 1).sum(), axis=1)
df['protection_engagement']  = df[['OnlineBackup','DeviceProtection']].apply(
                                   lambda r: (r == 1).sum(), axis=1)
df['engagement_tier']        = pd.cut(df['total_engagement'], bins=[-1,1,3,5,10],
                                       labels=[0,1,2,3]).astype(int)
print("  ✓ total_engagement, tech_engagement, entertainment_engagement, protection_engagement")
print("  ✓ has_internet, has_phone, engagement_tier")

# ============================================================================
# CATEGORY 4: RISK FLAGS
# ============================================================================

print("\n[STEP 5] Creating Risk Indicator Features...")

df['contract_risk']         = (df['Contract'] == 0).astype(int)            # Month-to-month
df['payment_risk']          = (df['PaymentMethod'] == 0).astype(int)       # Electronic check
df['quality_risk']          = ((df['InternetService'] == 1) &               # Fiber optic
                               (df['MonthlyCharges'] > 70)).astype(int)    # & high price
df['early_stage_risk']      = ((df['tenure'] <= 6) &
                               (df['Contract'] == 0)).astype(int)
df['low_engagement_risk']   = (df['total_engagement'] <= 1).astype(int)
df['combined_risk_score']   = (df['contract_risk'] + df['payment_risk'] +
                               df['quality_risk']  + df['early_stage_risk'] +
                               df['low_engagement_risk'])
print("  ✓ contract_risk, payment_risk, quality_risk, early_stage_risk, low_engagement_risk")
print("  ✓ combined_risk_score (0-5, higher = more risk)")

# ============================================================================
# CATEGORY 5: INTERACTION FEATURES
# ============================================================================

print("\n[STEP 6] Creating Interaction Features...")

df['price_per_tenure']      = np.where(df['tenure'] > 0,
                                df['MonthlyCharges'] / (df['tenure'] + 1), df['MonthlyCharges'])
df['early_premium']         = ((df['tenure'] <= 6) &
                               (df['MonthlyCharges'] > 65)).astype(int)
df['m2m_low_engagement']    = ((df['Contract'] == 0) &
                               (df['total_engagement'] <= 1)).astype(int)
df['value_misalignment']    = ((df['MonthlyCharges'] > 70) &
                               (df['total_engagement'] <= 2)).astype(int)
print("  ✓ price_per_tenure, early_premium, m2m_low_engagement, value_misalignment")

# ============================================================================
# CATEGORY 6: BEHAVIORAL FEATURES
# ============================================================================

print("\n[STEP 7] Creating Behavioral Features...")

df['has_family']            = ((df['Partner'] == 1) | (df['Dependents'] == 1)).astype(int)
df['tech_savvy']            = ((df['InternetService'] != -1) &
                               (df['OnlineSecurity'] == 1) &
                               (df['TechSupport'] == 1)).astype(int)
df['is_bundled']            = (df['total_engagement'] >= 3).astype(int)
df['paperless_auto']        = ((df['PaperlessBilling'] == 1) &
                               (df['PaymentMethod'] >= 2)).astype(int)
df['digital_preference']    = ((df['PaperlessBilling'] == 1) &
                               (df['InternetService'] != -1)).astype(int)
print("  ✓ has_family, tech_savvy, is_bundled, paperless_auto, digital_preference")

# ============================================================================
# DROP HELPER COLUMN
# ============================================================================

df.drop('total_services_raw', axis=1, inplace=True)

# ============================================================================
# VALIDATE
# ============================================================================

new_features = [c for c in df.columns if c not in original_cols]
print(f"\n[STEP 8] Summary:")
print(f"  Original features:    {len(original_cols)}")
print(f"  New features created: {len(new_features)}")
print(f"  Total features:       {df.shape[1]}")
print(f"  Dataset shape:        {df.shape}")
assert df.isnull().sum().sum() == 0, "Missing values after feature engineering!"
print(f"  ✓ No missing values introduced")

# ============================================================================
# FEATURE IMPORTANCE (correlation with Churn)
# ============================================================================

print("\n[STEP 9] Computing Feature Importance vs Churn...")
importance = {}
for col in new_features:
    try:
        corr, pval = stats.pointbiserialr(df['Churn'], df[col])
        importance[col] = {'abs_correlation': abs(corr), 'correlation': corr, 'pvalue': pval}
    except:
        importance[col] = {'abs_correlation': 0, 'correlation': 0, 'pvalue': 1}

imp_df = pd.DataFrame(importance).T.sort_values('abs_correlation', ascending=False)

# ============================================================================
# VISUALIZATION
# ============================================================================

print("\n[STEP 10] Generating Visualization...")
top_features = imp_df.head(20)
colors_imp   = ['#e74c3c' if v > 0 else '#27ae60' for v in top_features['correlation']]

fig, ax = plt.subplots(figsize=(10, 8))
ax.barh(range(len(top_features)), top_features['correlation'], color=colors_imp, edgecolor='black', alpha=0.85)
ax.set_yticks(range(len(top_features)))
ax.set_yticklabels(top_features.index, fontsize=9)
ax.set_xlabel('Correlation with Churn (|r|)')
ax.set_title('Engineered Feature Importance\n(Top 20 by Correlation with Churn)', fontweight='bold')
ax.axvline(0, color='black', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.savefig(FIGURE_PATH, dpi=150, bbox_inches='tight')
plt.close()
print(f"  ✓ Saved: {FIGURE_PATH}")

# ============================================================================
# SAVE OUTPUTS
# ============================================================================

df.to_csv(DATA_ENGINEERED, index=False)
print(f"  ✓ Engineered dataset: {DATA_ENGINEERED}")

feature_doc = pd.DataFrame({
    'Feature': new_features,
    'Category': ['Lifecycle']*4 + ['Value']*3 + ['Engagement']*8 +
                ['Risk']*6 + ['Interaction']*4 + ['Behavioral']*5,
    'Description': [
        'Customer lifecycle (0=New,1=Growth,2=Mature,3=Loyal)',
        'Flag: tenure ≤ 6 months (new customer)',
        'Flag: tenure > 24 months (loyal customer)',
        'Flag: tenure ≤ 6 months (critical retention window)',
        'Normalized total charges (0-100)',
        'Normalized monthly charges (0-100)',
        'Quartile of total charges (0=lowest, 3=highest)',
        'Count of all services adopted',
        'Flag: has active internet service',
        'Flag: has phone service',
        'Total product/service engagement score',
        'Count of tech services (Security+TechSupport)',
        'Count of entertainment (TV+Movies)',
        'Count of protection services (Backup+DevProtect)',
        'Service adoption tier (0=low, 3=high)',
        'Flag: month-to-month contract',
        'Flag: electronic check payment',
        'Flag: fiber optic + high price (quality risk)',
        'Flag: new + month-to-month (double risk)',
        'Flag: very low service engagement (0-1)',
        'Combined risk score (0-5)',
        'Monthly charges ÷ tenure (spend per month)',
        'Flag: new customer paying premium price',
        'Flag: month-to-month with low engagement',
        'Flag: high price but few services used',
        'Flag: has partner or dependents',
        'Flag: internet + security + tech support',
        'Flag: uses 3+ services (bundled customer)',
        'Flag: paperless billing + auto payment',
        'Flag: paperless + internet (digital-first customer)'
    ]
})
# Trim to actual count if mismatch
feature_doc = feature_doc.head(len(new_features))
feature_doc.to_csv(FEAT_DOC_PATH, index=False)
print(f"  ✓ Feature documentation: {FEAT_DOC_PATH}")

imp_df.to_csv(FEAT_IMP_PATH)
print(f"  ✓ Feature importance: {FEAT_IMP_PATH}")

report = f"""PHASE 6: FEATURE ENGINEERING SUMMARY
{'='*70}

INPUT:  {DATA_CLEANED}
OUTPUT: {DATA_ENGINEERED}

ORIGINAL FEATURES: {len(original_cols)}
NEW FEATURES:      {len(new_features)}
TOTAL FEATURES:    {df.shape[1]}

FEATURE CATEGORIES:
  1. Lifecycle Stage      (4 features) - tenure-based customer stages
  2. Customer Value       (3 features) - CLV and spend metrics
  3. Service Engagement   (8 features) - service adoption patterns
  4. Risk Indicators      (6 features) - churn risk flags
  5. Interaction Features (4 features) - cross-feature interactions
  6. Behavioral Features  (5 features) - customer behavior patterns

TOP 5 ENGINEERED FEATURES (by churn correlation):
{chr(10).join(f'  {i+1}. {f} (|r|={imp_df.iloc[i]["abs_correlation"]:.3f})' for i in range(min(5,len(imp_df))))}

VALIDATION: {df.isnull().sum().sum()} missing values (zero)

STATUS: ✓ Ready for Phase 7 (Feature Selection)
"""
with open(REPORT_PATH, 'w') as f:
    f.write(report)
print(f"  ✓ Report: {REPORT_PATH}")

# ============================================================================
# COMPLETE
# ============================================================================

print("\n" + "=" * 70)
print("✓ PHASE 6 COMPLETE — Ready for Phase 7: Feature Selection")
print("=" * 70)
print(f"\n  {len(new_features)} features created")
print(f"  Next: python scripts/07_feature_selection.py")
