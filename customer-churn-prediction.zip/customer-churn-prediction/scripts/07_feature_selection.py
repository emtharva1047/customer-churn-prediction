"""
================================================================================
PHASE 7: FEATURE SELECTION
Customer Churn Prediction Project
================================================================================
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')
from pathlib import Path
from scipy import stats
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import mutual_info_classif, RFE
from sklearn.preprocessing import StandardScaler
from statsmodels.stats.outliers_influence import variance_inflation_factor

# ============================================================================
# CONFIGURATION — ALL PATHS
# ============================================================================

DATA_ENGINEERED  = Path('data/processed/Telco-Customer-Churn-Engineered.csv')
DATA_SELECTED    = Path('data/processed/Telco-Customer-Churn-Selected-Features.csv')
SELECTED_LIST    = Path('data/processed/selected_features.csv')
ALL_METHODS_CSV  = Path('data/processed/feature_selection_all_methods.csv')
FIGURES_DIR      = Path('figures')
REPORTS_DIR      = Path('reports')
REPORT_PATH      = REPORTS_DIR / '07_feature_selection_summary.txt'
FIGURE_PATH      = FIGURES_DIR / '07_feature_selection_results.png'

Path('data/processed').mkdir(parents=True, exist_ok=True)
FIGURES_DIR.mkdir(parents=True, exist_ok=True)
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

try:
    plt.style.use('seaborn-v0_8-darkgrid')
except:
    plt.style.use('ggplot')

print("=" * 70)
print("PHASE 7: FEATURE SELECTION")
print("=" * 70)

# ============================================================================
# LOAD DATA
# ============================================================================

print("\n[STEP 1] Loading Engineered Dataset...")
if not DATA_ENGINEERED.exists():
    raise FileNotFoundError(
        f"✗ Not found: {DATA_ENGINEERED}\n"
        "  Run Phase 6 first: python scripts/06_feature_engineering.py"
    )
df = pd.read_csv(DATA_ENGINEERED)
print(f"✓ Loaded: {df.shape[0]:,} rows × {df.shape[1]} columns")

X = df.drop('Churn', axis=1)
y = df['Churn']
feature_names = X.columns.tolist()
print(f"  Features: {len(feature_names)}")

# ============================================================================
# METHOD 1: CORRELATION FILTER (p < 0.05)
# ============================================================================

print("\n[STEP 2] Method 1: Correlation Filter (p < 0.05)...")
corr_results = {}
for col in feature_names:
    try:
        r, p = stats.pointbiserialr(y, X[col])
        corr_results[col] = {'corr': r, 'abs_corr': abs(r), 'pval': p}
    except:
        corr_results[col] = {'corr': 0, 'abs_corr': 0, 'pval': 1}

corr_df = pd.DataFrame(corr_results).T
selected_corr = corr_df[corr_df['pval'] < 0.05].index.tolist()
print(f"  Features passing p<0.05 filter: {len(selected_corr)}")

# ============================================================================
# METHOD 2: VIF MULTICOLLINEARITY CHECK
# ============================================================================

print("\n[STEP 3] Method 2: VIF Multicollinearity Check (VIF < 10)...")
X_corr = X[selected_corr].copy()

# Iteratively remove highest VIF
def remove_high_vif(X_df, threshold=10, max_iter=50):
    cols = X_df.columns.tolist()
    for _ in range(max_iter):
        try:
            vif_data = pd.Series(
                [variance_inflation_factor(X_df[cols].values, i) for i in range(len(cols))],
                index=cols
            )
            max_vif = vif_data.max()
            if max_vif > threshold:
                remove_col = vif_data.idxmax()
                cols.remove(remove_col)
            else:
                break
        except Exception:
            break
    return cols

selected_vif = remove_high_vif(X_corr)
print(f"  Features after VIF filter: {len(selected_vif)}")

# ============================================================================
# METHOD 3: RANDOM FOREST IMPORTANCE (top 85%)
# ============================================================================

print("\n[STEP 4] Method 3: Random Forest Importance (top 85% cumulative)...")
X_vif = X[selected_vif]
rf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1,
                             class_weight='balanced')
rf.fit(X_vif, y)

importance_rf = pd.Series(rf.feature_importances_, index=selected_vif).sort_values(ascending=False)
cumulative    = importance_rf.cumsum() / importance_rf.sum()
selected_rf   = cumulative[cumulative <= 0.85].index.tolist()
# Ensure at least 10 features
if len(selected_rf) < 10:
    selected_rf = importance_rf.head(10).index.tolist()
print(f"  Features covering 85% importance: {len(selected_rf)}")

# ============================================================================
# METHOD 4: RECURSIVE FEATURE ELIMINATION (RFE)
# ============================================================================

print("\n[STEP 5] Method 4: RFE (n=15)...")
n_select = min(15, len(selected_vif))
rf_rfe   = RandomForestClassifier(n_estimators=50, random_state=42, n_jobs=-1,
                                    class_weight='balanced')
rfe      = RFE(rf_rfe, n_features_to_select=n_select)
rfe.fit(X_vif, y)
selected_rfe = X_vif.columns[rfe.support_].tolist()
print(f"  Features selected by RFE: {len(selected_rfe)}")

# ============================================================================
# METHOD 5: MUTUAL INFORMATION
# ============================================================================

print("\n[STEP 6] Method 5: Mutual Information (top 15)...")
mi_scores  = mutual_info_classif(X[selected_vif], y, random_state=42)
mi_series  = pd.Series(mi_scores, index=selected_vif).sort_values(ascending=False)
selected_mi = mi_series.head(n_select).index.tolist()
print(f"  Top MI features selected: {len(selected_mi)}")

# ============================================================================
# CONSENSUS: FEATURES SELECTED BY 2+ METHODS
# ============================================================================

print("\n[STEP 7] Consensus Ranking...")
all_selected = set(selected_rf) | set(selected_rfe) | set(selected_mi)
vote_counts  = {}
for feat in all_selected:
    votes = sum([
        feat in selected_corr,
        feat in selected_vif,
        feat in selected_rf,
        feat in selected_rfe,
        feat in selected_mi
    ])
    vote_counts[feat] = votes

votes_df = pd.Series(vote_counts).sort_values(ascending=False)
# Select features with at least 2 votes, cap at 15
final_features = votes_df[votes_df >= 2].head(15).index.tolist()

# Ensure Churn predictors are included (tenure, Contract, MonthlyCharges)
must_have = ['tenure', 'Contract', 'MonthlyCharges']
for f in must_have:
    if f in feature_names and f not in final_features:
        if len(final_features) < 15:
            final_features.append(f)
        else:
            final_features[-1] = f  # Replace last one

final_features = list(dict.fromkeys(final_features))  # deduplicate
print(f"  ✓ Final feature set: {len(final_features)} features")
print(f"  Features: {final_features}")

# ============================================================================
# VISUALIZATION
# ============================================================================

print("\n[STEP 8] Generating Visualization...")
fig, axes = plt.subplots(1, 2, figsize=(16, 6))

# Feature vote counts
top_voted = votes_df.head(20).sort_values()
colors_v  = ['#27ae60' if f in final_features else '#95a5a6' for f in top_voted.index]
axes[0].barh(range(len(top_voted)), top_voted.values, color=colors_v, edgecolor='black', alpha=0.85)
axes[0].set_yticks(range(len(top_voted)))
axes[0].set_yticklabels(top_voted.index, fontsize=8)
axes[0].set_xlabel('Number of Methods Selecting Feature')
axes[0].set_title('Feature Selection: Consensus Voting\n(Green = Selected)', fontweight='bold')
axes[0].axvline(x=2, color='red', linestyle='--', label='Min threshold (2 votes)')
axes[0].legend()

# RF importance of final features
final_imp = importance_rf.reindex(
    [f for f in final_features if f in importance_rf.index]
).fillna(0).sort_values(ascending=True)

colors_fi = ['#e74c3c' if v > final_imp.median() else '#3498db' for v in final_imp.values]
axes[1].barh(range(len(final_imp)), final_imp.values, color=colors_fi, edgecolor='black', alpha=0.85)
axes[1].set_yticks(range(len(final_imp)))
axes[1].set_yticklabels(final_imp.index, fontsize=9)
axes[1].set_xlabel('Random Forest Feature Importance')
axes[1].set_title('Final Selected Features\nRF Importance Scores', fontweight='bold')

plt.tight_layout()
plt.savefig(FIGURE_PATH, dpi=150, bbox_inches='tight')
plt.close()
print(f"  ✓ Saved: {FIGURE_PATH}")

# ============================================================================
# SAVE OUTPUTS
# ============================================================================

# Save selected dataset
df_selected = df[final_features + ['Churn']]
df_selected.to_csv(DATA_SELECTED, index=False)
print(f"\n  ✓ Selected dataset: {DATA_SELECTED}")
print(f"    Shape: {df_selected.shape}")

# Save selected features list
feat_list_df = pd.DataFrame({
    'Feature': final_features,
    'Votes':   [vote_counts.get(f, 0) for f in final_features],
    'RF_Importance': [importance_rf.get(f, 0) for f in final_features]
})
feat_list_df.to_csv(SELECTED_LIST, index=False)
print(f"  ✓ Feature list: {SELECTED_LIST}")

# Save all methods comparison
all_df = pd.DataFrame(index=feature_names)
all_df['Correlation_Selected'] = all_df.index.isin(selected_corr)
all_df['VIF_Selected']         = all_df.index.isin(selected_vif)
all_df['RF_Selected']          = all_df.index.isin(selected_rf)
all_df['RFE_Selected']         = all_df.index.isin(selected_rfe)
all_df['MI_Selected']          = all_df.index.isin(selected_mi)
all_df['Final_Selected']       = all_df.index.isin(final_features)
all_df['Votes']                = all_df.index.map(lambda x: vote_counts.get(x, 0))
all_df.to_csv(ALL_METHODS_CSV)
print(f"  ✓ All methods comparison: {ALL_METHODS_CSV}")

report = f"""PHASE 7: FEATURE SELECTION SUMMARY
{'='*70}

INPUT:  {DATA_ENGINEERED} ({df.shape[1]} features)
OUTPUT: {DATA_SELECTED}   ({len(final_features)} features)

METHODS APPLIED:
  1. Correlation Filter (p < 0.05):     {len(selected_corr)} features
  2. VIF Multicollinearity (< 10):      {len(selected_vif)} features
  3. Random Forest Importance (top 85%): {len(selected_rf)} features
  4. RFE (n=15):                        {len(selected_rfe)} features
  5. Mutual Information (top 15):       {len(selected_mi)} features

FINAL SELECTION: {len(final_features)} features (consensus of 2+ methods)

SELECTED FEATURES:
{chr(10).join(f'  {i+1:2d}. {f}' for i,f in enumerate(final_features))}

STATUS: ✓ Ready for Phase 8-12 (Model Development)
"""
with open(REPORT_PATH, 'w') as f:
    f.write(report)
print(f"  ✓ Report: {REPORT_PATH}")

# ============================================================================
# COMPLETE
# ============================================================================

print("\n" + "=" * 70)
print("✓ PHASE 7 COMPLETE — Ready for Phases 8-12: Model Development")
print("=" * 70)
print(f"\n  {len(final_features)} optimal features selected from {len(feature_names)}")
print(f"  Next: python scripts/08_12_model_development.py")
