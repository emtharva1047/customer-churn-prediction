"""
================================================================================
PHASE 3: DATA UNDERSTANDING
Customer Churn Prediction Project
================================================================================
"""

import os
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

# ============================================================================
# CONFIGURATION - ALL PATHS DEFINED HERE
# ============================================================================

# Input
DATA_RAW       = Path('data/raw/Telco-Customer-Churn.csv')

# Outputs
FIGURES_DIR    = Path('figures')
REPORTS_DIR    = Path('reports')

# Create output directories
FIGURES_DIR.mkdir(parents=True, exist_ok=True)
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

# Plot style
try:
    plt.style.use('seaborn-v0_8-darkgrid')
except:
    plt.style.use('ggplot')

print("=" * 70)
print("PHASE 3: DATA UNDERSTANDING")
print("=" * 70)

# ============================================================================
# STEP 1: LOAD DATA
# ============================================================================

print("\n[STEP 1] Loading Dataset...")
if not DATA_RAW.exists():
    raise FileNotFoundError(
        f"\n✗ Dataset not found at: {DATA_RAW}\n"
        "  Download from: https://www.kaggle.com/blastchar/telco-customer-churn\n"
        "  Then place it at: data/raw/Telco-Customer-Churn.csv"
    )

df = pd.read_csv(DATA_RAW)
print(f"✓ Dataset loaded: {DATA_RAW}")
print(f"  Shape: {df.shape[0]:,} rows × {df.shape[1]} columns")
print(f"  Memory: {df.memory_usage(deep=True).sum() / 1024**2:.2f} MB")

# ============================================================================
# STEP 2: BASIC INSPECTION
# ============================================================================

print("\n[STEP 2] Data Types & Column Info...")
print("-" * 70)

dtype_df = pd.DataFrame({
    'Column':        df.columns,
    'DType':         df.dtypes.astype(str).values,
    'Non-Null':      df.count().values,
    'Null':          df.isnull().sum().values,
    'Unique Values': df.nunique().values
})
print(dtype_df.to_string(index=False))

# ============================================================================
# STEP 3: MISSING VALUES
# ============================================================================

print("\n[STEP 3] Missing Values...")
print("-" * 70)
missing = df.isnull().sum()
if missing.sum() == 0:
    print("✓ No missing values in any column.")
else:
    print(missing[missing > 0].to_string())

# ============================================================================
# STEP 4: DUPLICATES
# ============================================================================

print("\n[STEP 4] Duplicate Detection...")
print("-" * 70)
dup_rows = df.duplicated().sum()
dup_ids  = df['customerID'].duplicated().sum() if 'customerID' in df.columns else 0
print(f"  Duplicate rows:       {dup_rows}")
print(f"  Duplicate customerID: {dup_ids}")
if dup_rows == 0 and dup_ids == 0:
    print("✓ No duplicates found.")

# ============================================================================
# STEP 5: NUMERIC SUMMARY
# ============================================================================

print("\n[STEP 5] Numeric Columns - Statistical Summary...")
print("-" * 70)
numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
print(f"  Numeric columns ({len(numeric_cols)}): {numeric_cols}\n")
print(df[numeric_cols].describe().T.to_string())

# ============================================================================
# STEP 6: CATEGORICAL SUMMARY
# ============================================================================

print("\n[STEP 6] Categorical Columns - Unique Values...")
print("-" * 70)
cat_cols = df.select_dtypes(include='object').columns.tolist()
for col in cat_cols:
    print(f"  {col} [{df[col].nunique()} unique]: {sorted(df[col].unique())[:5]}{'...' if df[col].nunique() > 5 else ''}")

# ============================================================================
# STEP 7: TARGET VARIABLE
# ============================================================================

print("\n[STEP 7] Target Variable: Churn Distribution...")
print("-" * 70)
churn_counts = df['Churn'].value_counts()
churn_pcts   = df['Churn'].value_counts(normalize=True) * 100
for val in churn_counts.index:
    print(f"  {val}: {churn_counts[val]:,} ({churn_pcts[val]:.1f}%)")
churn_ratio = churn_counts.get('No', 0) / churn_counts.get('Yes', 1)
print(f"\n  Class imbalance ratio: {churn_ratio:.2f}:1 (No:Yes)")
print(f"  ⚠ This is a moderately imbalanced dataset — use stratification & class weights")

# ============================================================================
# STEP 8: DATA QUALITY ISSUES
# ============================================================================

print("\n[STEP 8] Data Quality Issues Identified...")
print("-" * 70)
issues = []
if 'TotalCharges' in df.columns and df['TotalCharges'].dtype == object:
    bad = df[pd.to_numeric(df['TotalCharges'], errors='coerce').isnull()]['TotalCharges'].unique()
    print(f"  ⚠ Issue 1: TotalCharges is string dtype (should be float)")
    print(f"             Non-numeric values: {bad}")
    issues.append("TotalCharges needs numeric conversion")
if 'SeniorCitizen' in df.columns and df['SeniorCitizen'].dtype in [int, 'int64']:
    print(f"  ⚠ Issue 2: SeniorCitizen uses 0/1 encoding (others use Yes/No)")
    issues.append("SeniorCitizen encoding inconsistency")
print(f"  ⚠ Issue 3: Add-on columns encode 'No internet service' as category")
issues.append("Add-on columns: 'No internet service' category needs ordinal encoding")
print(f"  ⚠ Issue 4: Class imbalance (26.5% churn) — needs balancing strategy")
issues.append("Class imbalance 26.5% vs 73.5% — use class_weight='balanced'")
print(f"\n  Total issues found: {len(issues)} — all addressable in Phase 4")

# ============================================================================
# STEP 9: VISUALIZATIONS
# ============================================================================

print("\n[STEP 9] Generating Visualizations...")
print("-" * 70)

# Figure 1: Target Distribution
fig, axes = plt.subplots(1, 2, figsize=(12, 5))
colors = ['#2ecc71', '#e74c3c']
axes[0].bar(churn_counts.index, churn_counts.values, color=colors, edgecolor='black')
axes[0].set_title('Churn Count', fontsize=13, fontweight='bold')
axes[0].set_ylabel('Customers')
for i, v in enumerate(churn_counts.values):
    axes[0].text(i, v + 30, f'{v:,}', ha='center', fontweight='bold')

axes[1].bar(churn_pcts.index, churn_pcts.values, color=colors, edgecolor='black')
axes[1].set_title('Churn Percentage', fontsize=13, fontweight='bold')
axes[1].set_ylabel('Percentage (%)')
axes[1].set_ylim(0, 100)
for i, v in enumerate(churn_pcts.values):
    axes[1].text(i, v + 1.5, f'{v:.1f}%', ha='center', fontweight='bold')

plt.suptitle('Target Variable: Churn Distribution', fontsize=15, fontweight='bold')
plt.tight_layout()
path = FIGURES_DIR / '01_target_distribution.png'
plt.savefig(path, dpi=150, bbox_inches='tight')
plt.close()
print(f"  ✓ Saved: {path}")

# Figure 2: Data Types
fig, ax = plt.subplots(figsize=(8, 4))
dtype_counts = df.dtypes.astype(str).value_counts()
ax.bar(dtype_counts.index, dtype_counts.values, color=sns.color_palette("Set2", len(dtype_counts)), edgecolor='black')
ax.set_title('Data Type Distribution', fontsize=13, fontweight='bold')
ax.set_ylabel('Number of Columns')
for i, v in enumerate(dtype_counts.values):
    ax.text(i, v + 0.1, str(v), ha='center', fontweight='bold')
plt.tight_layout()
path = FIGURES_DIR / '02_datatype_distribution.png'
plt.savefig(path, dpi=150, bbox_inches='tight')
plt.close()
print(f"  ✓ Saved: {path}")

# Figure 3: Completeness
fig, ax = plt.subplots(figsize=(12, 7))
completeness = (df.count() / len(df) * 100).sort_values()
cols_colors  = ['#27ae60' if v == 100 else '#e67e22' for v in completeness.values]
ax.barh(range(len(completeness)), completeness.values, color=cols_colors, edgecolor='black')
ax.set_yticks(range(len(completeness)))
ax.set_yticklabels(completeness.index, fontsize=9)
ax.set_xlabel('Completeness (%)')
ax.set_title('Column Data Completeness', fontsize=13, fontweight='bold')
ax.set_xlim([85, 101])
plt.tight_layout()
path = FIGURES_DIR / '03_column_completeness.png'
plt.savefig(path, dpi=150, bbox_inches='tight')
plt.close()
print(f"  ✓ Saved: {path}")

# ============================================================================
# STEP 10: SAVE SUMMARY REPORT
# ============================================================================

summary = f"""PHASE 3: DATA UNDERSTANDING SUMMARY
{'='*70}

DATASET: {DATA_RAW}
SHAPE: {df.shape[0]:,} rows × {df.shape[1]} columns
MEMORY: {df.memory_usage(deep=True).sum() / 1024**2:.2f} MB

TARGET VARIABLE (Churn):
  No  (Retained): {churn_counts.get('No',0):,} ({churn_pcts.get('No',0):.1f}%)
  Yes (Churned):  {churn_counts.get('Yes',0):,} ({churn_pcts.get('Yes',0):.1f}%)
  Imbalance ratio: {churn_ratio:.2f}:1

MISSING VALUES: {df.isnull().sum().sum()} (zero missing values)
DUPLICATES:     {dup_rows} duplicate rows | {dup_ids} duplicate IDs

DATA QUALITY ISSUES FOUND ({len(issues)}):
""" + "\n".join(f"  {i+1}. {iss}" for i, iss in enumerate(issues)) + f"""

NUMERIC COLUMNS ({len(numeric_cols)}): {numeric_cols}
CATEGORICAL COLUMNS ({len(cat_cols)}): {cat_cols}

STATUS: ✓ Ready for Phase 4 (Data Cleaning)
"""

report_path = REPORTS_DIR / '03_data_understanding_summary.txt'
with open(report_path, 'w') as f:
    f.write(summary)
    f.write("\n\nFULL STATISTICS:\n")
    f.write(df.describe(include='all').to_string())
print(f"\n  ✓ Report saved: {report_path}")

# ============================================================================
# COMPLETE
# ============================================================================

print("\n" + "=" * 70)
print("✓ PHASE 3 COMPLETE — Ready for Phase 4: Data Cleaning")
print("=" * 70)
print(f"\n  Output files:")
print(f"    Figures → {FIGURES_DIR}/")
print(f"    Report  → {report_path}")
print(f"\n  Next: python scripts/04_data_cleaning.py")
