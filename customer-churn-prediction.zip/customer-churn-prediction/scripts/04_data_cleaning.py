"""
================================================================================
PHASE 4: DATA CLEANING
Customer Churn Prediction Project
================================================================================
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

# ============================================================================
# CONFIGURATION — ALL PATHS
# ============================================================================

DATA_RAW       = Path('data/raw/Telco-Customer-Churn.csv')
DATA_PROCESSED = Path('data/processed')
FIGURES_DIR    = Path('figures')
REPORTS_DIR    = Path('reports')

DATA_CLEANED   = DATA_PROCESSED / 'Telco-Customer-Churn-Cleaned.csv'
DICT_PATH      = DATA_PROCESSED / 'data_dictionary_cleaned.csv'
REPORT_PATH    = REPORTS_DIR    / '04_cleaning_summary.txt'
FIGURE_PATH    = FIGURES_DIR    / '04_data_cleaning_comparison.png'

# Create directories
DATA_PROCESSED.mkdir(parents=True, exist_ok=True)
FIGURES_DIR.mkdir(parents=True, exist_ok=True)
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

try:
    plt.style.use('seaborn-v0_8-darkgrid')
except:
    plt.style.use('ggplot')

print("=" * 70)
print("PHASE 4: DATA CLEANING")
print("=" * 70)

# ============================================================================
# STEP 1: LOAD RAW DATA
# ============================================================================

print("\n[STEP 1] Loading Raw Dataset...")
if not DATA_RAW.exists():
    raise FileNotFoundError(
        f"✗ Dataset not found at: {DATA_RAW}\n"
        "  Download from: https://www.kaggle.com/blastchar/telco-customer-churn\n"
        "  Place at: data/raw/Telco-Customer-Churn.csv"
    )
df_raw = pd.read_csv(DATA_RAW)
df     = df_raw.copy()
print(f"✓ Loaded: {df.shape[0]:,} rows × {df.shape[1]} columns")

# ============================================================================
# STEP 2: REMOVE CUSTOMER ID (non-predictive)
# ============================================================================

print("\n[STEP 2] Removing Non-Predictive Columns...")
if 'customerID' in df.columns:
    df.drop('customerID', axis=1, inplace=True)
    print("  ✓ Removed: customerID")

# ============================================================================
# STEP 3: FIX TOTALCHARGES (string → float)
# ============================================================================

print("\n[STEP 3] Fixing TotalCharges (string → float)...")
before_type = df['TotalCharges'].dtype
df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce')
# New customers (tenure=0) have empty TotalCharges → fill with 0
n_null = df['TotalCharges'].isnull().sum()
df['TotalCharges'].fillna(0.0, inplace=True)
print(f"  ✓ Converted to float64")
print(f"  ✓ Filled {n_null} NaN values with 0.0 (new customers with no charges yet)")

# ============================================================================
# STEP 4: ENCODE TARGET (Churn: Yes→1, No→0)
# ============================================================================

print("\n[STEP 4] Encoding Target Variable (Churn: Yes→1, No→0)...")
df['Churn'] = (df['Churn'] == 'Yes').astype(int)
print(f"  ✓ Churn encoded: {df['Churn'].value_counts().to_dict()}")

# ============================================================================
# STEP 5: ENCODE BINARY FEATURES (Yes/No → 1/0)
# ============================================================================

print("\n[STEP 5] Encoding Binary Features (Yes/No → 1/0)...")
binary_cols = ['Partner', 'Dependents', 'PhoneService', 'PaperlessBilling']
for col in binary_cols:
    if col in df.columns:
        df[col] = (df[col] == 'Yes').astype(int)
        print(f"  ✓ {col}: Yes→1, No→0")

# gender: Female→0, Male→1
if 'gender' in df.columns:
    df['gender'] = (df['gender'] == 'Male').astype(int)
    print(f"  ✓ gender: Male→1, Female→0")

# SeniorCitizen already 0/1 — confirm
if 'SeniorCitizen' in df.columns:
    df['SeniorCitizen'] = df['SeniorCitizen'].astype(int)
    print(f"  ✓ SeniorCitizen: already 0/1 (kept as-is)")

# ============================================================================
# STEP 6: ENCODE ADD-ON FEATURES (ordinal: No internet=-1, No=0, Yes=1)
# ============================================================================

print("\n[STEP 6] Encoding Add-on Features (ordinal: -1/0/1)...")
addons = ['OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
          'TechSupport', 'StreamingTV', 'StreamingMovies']

def encode_addon(val):
    if val == 'No internet service':
        return -1
    elif val == 'No':
        return 0
    else:  # Yes
        return 1

for col in addons:
    if col in df.columns:
        df[col] = df[col].apply(encode_addon)
        print(f"  ✓ {col}: No internet service→-1, No→0, Yes→1")

# ============================================================================
# STEP 7: ENCODE MULTIPLE LINES (ordinal)
# ============================================================================

print("\n[STEP 7] Encoding MultipleLines...")
if 'MultipleLines' in df.columns:
    ml_map = {'No phone service': -1, 'No': 0, 'Yes': 1}
    df['MultipleLines'] = df['MultipleLines'].map(ml_map)
    print("  ✓ MultipleLines: No phone service→-1, No→0, Yes→1")

# ============================================================================
# STEP 8: ENCODE INTERNET SERVICE
# ============================================================================

print("\n[STEP 8] Encoding InternetService...")
if 'InternetService' in df.columns:
    is_map = {'No': -1, 'DSL': 0, 'Fiber optic': 1}
    df['InternetService'] = df['InternetService'].map(is_map)
    print("  ✓ InternetService: No→-1, DSL→0, Fiber optic→1")

# ============================================================================
# STEP 9: ENCODE CONTRACT TYPE
# ============================================================================

print("\n[STEP 9] Encoding Contract (ordinal)...")
if 'Contract' in df.columns:
    contract_map = {'Month-to-month': 0, 'One year': 1, 'Two year': 2}
    df['Contract'] = df['Contract'].map(contract_map)
    print("  ✓ Contract: Month-to-month→0, One year→1, Two year→2")

# ============================================================================
# STEP 10: ENCODE PAYMENT METHOD
# ============================================================================

print("\n[STEP 10] Encoding PaymentMethod...")
if 'PaymentMethod' in df.columns:
    pm_map = {
        'Electronic check':    0,
        'Mailed check':        1,
        'Bank transfer (automatic)': 2,
        'Credit card (automatic)':   3
    }
    df['PaymentMethod'] = df['PaymentMethod'].map(pm_map)
    print("  ✓ PaymentMethod: Electronic check→0, Mailed check→1, Bank→2, Credit→3")

# ============================================================================
# STEP 11: VALIDATE RESULT
# ============================================================================

print("\n[STEP 11] Validation...")
n_missing   = df.isnull().sum().sum()
n_non_num   = len(df.select_dtypes(include='object').columns)
n_dup       = df.duplicated().sum()

print(f"  Shape:               {df.shape}")
print(f"  Missing values:      {n_missing}")
print(f"  Non-numeric columns: {n_non_num}")
print(f"  Duplicates:          {n_dup}")

if n_missing > 0:
    print(f"  ⚠ Missing value columns: {df.columns[df.isnull().any()].tolist()}")
if n_non_num > 0:
    print(f"  ⚠ Object columns remaining: {df.select_dtypes('object').columns.tolist()}")

assert n_missing   == 0, f"Missing values found: {n_missing}"
assert n_non_num   == 0, f"Non-numeric columns found"
print("  ✓ All checks passed — dataset is fully numeric, no missing values")

# ============================================================================
# STEP 12: SAVE CLEANED DATASET
# ============================================================================

print("\n[STEP 12] Saving Cleaned Dataset...")
df.to_csv(DATA_CLEANED, index=False)
print(f"  ✓ Saved: {DATA_CLEANED}")
print(f"  Shape: {df.shape[0]:,} rows × {df.shape[1]} columns")

# Save data dictionary
dict_data = []
for col in df.columns:
    dict_data.append({
        'Feature': col,
        'Type':    df[col].dtype,
        'Min':     df[col].min(),
        'Max':     df[col].max(),
        'Unique':  df[col].nunique()
    })
pd.DataFrame(dict_data).to_csv(DICT_PATH, index=False)
print(f"  ✓ Saved data dictionary: {DICT_PATH}")

# ============================================================================
# STEP 13: VISUALIZATION
# ============================================================================

print("\n[STEP 13] Generating Visualization...")
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# Before: raw dtypes
raw_types = df_raw.dtypes.astype(str).value_counts()
axes[0].bar(raw_types.index, raw_types.values, color=['#e74c3c','#3498db','#2ecc71'], edgecolor='black')
axes[0].set_title('BEFORE Cleaning: Data Types', fontsize=13, fontweight='bold')
axes[0].set_ylabel('Column Count')
for i, v in enumerate(raw_types.values):
    axes[0].text(i, v + 0.1, str(v), ha='center', fontweight='bold')

# After: cleaned dtypes
clean_types = df.dtypes.astype(str).value_counts()
axes[1].bar(clean_types.index, clean_types.values, color=['#27ae60','#2980b9'], edgecolor='black')
axes[1].set_title('AFTER Cleaning: Data Types', fontsize=13, fontweight='bold')
axes[1].set_ylabel('Column Count')
for i, v in enumerate(clean_types.values):
    axes[1].text(i, v + 0.1, str(v), ha='center', fontweight='bold')

plt.suptitle('Data Cleaning: Before vs After', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig(FIGURE_PATH, dpi=150, bbox_inches='tight')
plt.close()
print(f"  ✓ Saved: {FIGURE_PATH}")

# ============================================================================
# STEP 14: SAVE REPORT
# ============================================================================

report = f"""PHASE 4: DATA CLEANING SUMMARY
{'='*70}

INPUT:  {DATA_RAW}
OUTPUT: {DATA_CLEANED}

SHAPE BEFORE: {df_raw.shape[0]:,} rows × {df_raw.shape[1]} columns
SHAPE AFTER:  {df.shape[0]:,} rows × {df.shape[1]} columns

TRANSFORMATIONS APPLIED:
  1. Removed: customerID (non-predictive identifier)
  2. Fixed:   TotalCharges (string→float, {n_null} NaN→0.0 for new customers)
  3. Encoded: Churn (Yes→1, No→0)
  4. Encoded: gender (Male→1, Female→0)
  5. Encoded: Partner, Dependents, PhoneService, PaperlessBilling (Yes→1, No→0)
  6. Encoded: SeniorCitizen (already 0/1, confirmed)
  7. Encoded: Add-ons (No internet service→-1, No→0, Yes→1) [6 columns]
  8. Encoded: MultipleLines (No phone service→-1, No→0, Yes→1)
  9. Encoded: InternetService (No→-1, DSL→0, Fiber optic→1)
  10. Encoded: Contract (Month-to-month→0, One year→1, Two year→2)
  11. Encoded: PaymentMethod (Electronic→0, Mailed→1, Bank→2, Credit→3)

VALIDATION:
  Missing values:      0 ✓
  Non-numeric columns: 0 ✓
  Duplicate rows:      {n_dup} ✓

STATUS: ✓ Ready for Phase 5 (EDA)
"""

with open(REPORT_PATH, 'w') as f:
    f.write(report)
print(f"  ✓ Report saved: {REPORT_PATH}")

# ============================================================================
# COMPLETE
# ============================================================================

print("\n" + "=" * 70)
print("✓ PHASE 4 COMPLETE — Ready for Phase 5: EDA")
print("=" * 70)
print(f"\n  Output files:")
print(f"    Cleaned data → {DATA_CLEANED}")
print(f"    Dictionary   → {DICT_PATH}")
print(f"    Figure       → {FIGURE_PATH}")
print(f"    Report       → {REPORT_PATH}")
print(f"\n  Next: python scripts/05_exploratory_data_analysis.py")
