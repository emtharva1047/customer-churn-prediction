"""
================================================================================
PHASES 8-12: MODEL DEVELOPMENT, TUNING & EVALUATION
Customer Churn Prediction Project
================================================================================
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pickle
import warnings
warnings.filterwarnings('ignore')
from pathlib import Path
from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                              f1_score, roc_auc_score, confusion_matrix,
                              roc_curve)
from sklearn.inspection import permutation_importance
try:
    from xgboost import XGBClassifier
    HAS_XGB = True
except ImportError:
    HAS_XGB = False
    print("  ⚠ XGBoost not available, skipping")

try:
    from lightgbm import LGBMClassifier
    HAS_LGB = True
except ImportError:
    HAS_LGB = False
    print("  ⚠ LightGBM not available, skipping")

# ============================================================================
# CONFIGURATION — ALL PATHS
# ============================================================================

DATA_SELECTED   = Path('data/processed/Telco-Customer-Churn-Selected-Features.csv')
MODEL_DIR       = Path('models')
RESULTS_DIR     = Path('results')
FIGURES_DIR     = Path('figures')
REPORTS_DIR     = Path('reports')

MODEL_PATH      = MODEL_DIR    / 'best_model.pkl'
COMPARISON_PATH = RESULTS_DIR  / 'model_comparison.csv'
PERM_IMP_PATH   = RESULTS_DIR  / 'feature_importance_permutation.csv'
FIGURE_PATH     = FIGURES_DIR  / '08_12_model_evaluation.png'
REPORT_PATH     = REPORTS_DIR  / '08_12_model_development_summary.txt'

MODEL_DIR.mkdir(parents=True, exist_ok=True)
RESULTS_DIR.mkdir(parents=True, exist_ok=True)
FIGURES_DIR.mkdir(parents=True, exist_ok=True)
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

try:
    plt.style.use('seaborn-v0_8-darkgrid')
except:
    plt.style.use('ggplot')

print("=" * 70)
print("PHASES 8-12: MODEL DEVELOPMENT & EVALUATION")
print("=" * 70)

# ============================================================================
# PHASE 8: LOAD & SPLIT DATA
# ============================================================================

print("\n[PHASE 8] Data Split...")
if not DATA_SELECTED.exists():
    raise FileNotFoundError(
        f"✗ Not found: {DATA_SELECTED}\n"
        "  Run Phase 7 first: python scripts/07_feature_selection.py"
    )
df = pd.read_csv(DATA_SELECTED)
X  = df.drop('Churn', axis=1)
y  = df['Churn']
feature_names = X.columns.tolist()

print(f"  Dataset: {df.shape[0]:,} rows | {len(feature_names)} features | Churn rate: {y.mean()*100:.1f}%")

# Train(60) / Val(20) / Test(20) — all stratified
X_temp, X_test, y_temp, y_test = train_test_split(X, y, test_size=0.20, random_state=42, stratify=y)
X_train, X_val, y_train, y_val = train_test_split(X_temp, y_temp, test_size=0.25, random_state=42, stratify=y_temp)

print(f"  Train: {len(X_train):,} | Val: {len(X_val):,} | Test: {len(X_test):,}")
print(f"  Train churn: {y_train.mean()*100:.1f}% | Test churn: {y_test.mean()*100:.1f}%")

# Scale for Logistic Regression
scaler  = StandardScaler()
X_train_sc = scaler.fit_transform(X_train)
X_val_sc   = scaler.transform(X_val)
X_test_sc  = scaler.transform(X_test)

# ============================================================================
# PHASE 9: DEFINE & TRAIN MODELS
# ============================================================================

print("\n[PHASE 9] Training Models...")

models = {
    'Logistic Regression': LogisticRegression(
        class_weight='balanced', max_iter=1000, random_state=42),
    'Decision Tree': DecisionTreeClassifier(
        max_depth=6, class_weight='balanced', random_state=42),
    'Random Forest': RandomForestClassifier(
        n_estimators=100, class_weight='balanced', random_state=42, n_jobs=-1),
    'Gradient Boosting': GradientBoostingClassifier(
        n_estimators=100, learning_rate=0.1, max_depth=4, random_state=42),
}

if HAS_XGB:
    scale_pos = float((y == 0).sum()) / float((y == 1).sum())
    models['XGBoost'] = XGBClassifier(
        n_estimators=100, scale_pos_weight=scale_pos,
        random_state=42, eval_metric='logloss',
        use_label_encoder=False if hasattr(XGBClassifier, 'use_label_encoder') else None
    )

if HAS_LGB:
    models['LightGBM'] = LGBMClassifier(
        n_estimators=100, is_unbalance=True, random_state=42,
        verbose=-1, force_col_wise=True)

def evaluate(model, X_tr, y_tr, X_va, y_va, X_te, y_te, scaled=False):
    if scaled:
        model.fit(X_tr, y_tr)
        val_proba  = model.predict_proba(X_va)[:,1]
        test_proba = model.predict_proba(X_te)[:,1]
        test_pred  = model.predict(X_te)
    else:
        model.fit(X_tr, y_tr)
        val_proba  = model.predict_proba(X_va)[:,1]
        test_proba = model.predict_proba(X_te)[:,1]
        test_pred  = model.predict(X_te)

    return {
        'Val_AUC':     round(roc_auc_score(y_va, val_proba), 4),
        'Test_AUC':    round(roc_auc_score(y_te, test_proba), 4),
        'Accuracy':    round(accuracy_score(y_te, test_pred), 4),
        'Precision':   round(precision_score(y_te, test_pred, zero_division=0), 4),
        'Recall':      round(recall_score(y_te, test_pred, zero_division=0), 4),
        'F1':          round(f1_score(y_te, test_pred, zero_division=0), 4),
        'test_proba':  test_proba,
        'test_pred':   test_pred
    }

results = {}
for name, model in models.items():
    print(f"  Training: {name}...", end=' ', flush=True)
    try:
        is_lr = name == 'Logistic Regression'
        metrics = evaluate(
            model,
            X_train_sc if is_lr else X_train, y_train,
            X_val_sc   if is_lr else X_val,   y_val,
            X_test_sc  if is_lr else X_test,  y_test,
            scaled=is_lr
        )
        results[name] = metrics
        print(f"AUC={metrics['Test_AUC']:.4f}  F1={metrics['F1']:.4f}  ✓")
    except Exception as e:
        print(f"✗ Error: {e}")

# ============================================================================
# PHASE 10: HYPERPARAMETER TUNING (best 2 models)
# ============================================================================

print("\n[PHASE 10] Hyperparameter Tuning (best non-LR models)...")

# Sort by AUC, pick top tree models
tree_results = {k: v for k, v in results.items() if k != 'Logistic Regression'}
if tree_results:
    top_model_name = max(tree_results, key=lambda k: tree_results[k]['Test_AUC'])

    if 'Gradient Boosting' in results:
        print("  Tuning Gradient Boosting...")
        gb_params = {
            'n_estimators': [100, 200],
            'learning_rate': [0.05, 0.1],
            'max_depth': [3, 4]
        }
        gb_cv = GridSearchCV(
            GradientBoostingClassifier(random_state=42),
            gb_params, cv=StratifiedKFold(3), scoring='roc_auc', n_jobs=-1
        )
        gb_cv.fit(X_train, y_train)
        best_gb = gb_cv.best_estimator_
        metrics = evaluate(best_gb, X_train, y_train, X_val, y_val, X_test, y_test)
        results['Gradient Boosting (Tuned)'] = metrics
        models['Gradient Boosting (Tuned)'] = best_gb
        print(f"  ✓ Best params: {gb_cv.best_params_}  AUC={metrics['Test_AUC']:.4f}")

# ============================================================================
# PHASE 11: SELECT BEST MODEL
# ============================================================================

print("\n[PHASE 11] Selecting Best Model...")
best_name  = max(results, key=lambda k: results[k]['Test_AUC'])
best_metrics = results[best_name]
best_model   = models[best_name] if best_name in models else models.get(best_name.replace(' (Tuned)',''))

print(f"\n  ★ Best Model: {best_name}")
print(f"    Test AUC:    {best_metrics['Test_AUC']}")
print(f"    Accuracy:    {best_metrics['Accuracy']}")
print(f"    Precision:   {best_metrics['Precision']}")
print(f"    Recall:      {best_metrics['Recall']}")
print(f"    F1-Score:    {best_metrics['F1']}")

cm = confusion_matrix(y_test, best_metrics['test_pred'])
print(f"\n  Confusion Matrix:")
print(f"    TN={cm[0,0]:4d}  FP={cm[0,1]:4d}")
print(f"    FN={cm[1,0]:4d}  TP={cm[1,1]:4d}")

# ============================================================================
# PHASE 12: INTERPRETABILITY
# ============================================================================

print("\n[PHASE 12] Permutation Importance...")
try:
    perm_result = permutation_importance(
        best_model, X_test, y_test,
        n_repeats=10, random_state=42, scoring='roc_auc'
    )
    perm_imp = pd.DataFrame({
        'feature':    feature_names,
        'importance': perm_result.importances_mean,
        'std':        perm_result.importances_std
    }).sort_values('importance', ascending=False)
    perm_imp.to_csv(PERM_IMP_PATH, index=False)
    print(f"  ✓ Permutation importance saved: {PERM_IMP_PATH}")
    print(f"  Top 5: {perm_imp['feature'].head(5).tolist()}")
except Exception as e:
    print(f"  ⚠ Permutation importance failed: {e}")
    perm_imp = pd.DataFrame({'feature': feature_names, 'importance': [0]*len(feature_names)})

# ============================================================================
# VISUALIZATION
# ============================================================================

print("\n[STEP] Generating Visualizations...")
fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# 1. Model comparison
model_names  = list(results.keys())
auc_scores   = [results[m]['Test_AUC'] for m in model_names]
colors_bars  = ['#e74c3c' if m == best_name else '#3498db' for m in model_names]
short_names  = [m.replace(' (Tuned)','*').replace(' ','\\n') for m in model_names]

axes[0,0].bar(range(len(model_names)), auc_scores, color=colors_bars, edgecolor='black', alpha=0.85)
axes[0,0].set_xticks(range(len(model_names)))
axes[0,0].set_xticklabels(short_names, fontsize=8)
axes[0,0].set_title('Model Comparison: AUC-ROC\n(Red = Best)', fontweight='bold')
axes[0,0].set_ylabel('AUC-ROC')
axes[0,0].set_ylim([0.5, 1.0])
for i, v in enumerate(auc_scores):
    axes[0,0].text(i, v + 0.005, f'{v:.3f}', ha='center', fontsize=8, fontweight='bold')

# 2. ROC curves
for name, met in results.items():
    fpr, tpr, _ = roc_curve(y_test, met['test_proba'])
    lw = 3 if name == best_name else 1
    axes[0,1].plot(fpr, tpr, lw=lw, label=f'{name} ({met["Test_AUC"]:.3f})')
axes[0,1].plot([0,1],[0,1],'k--', alpha=0.5)
axes[0,1].set_title('ROC Curves', fontweight='bold')
axes[0,1].set_xlabel('False Positive Rate')
axes[0,1].set_ylabel('True Positive Rate')
axes[0,1].legend(fontsize=7)

# 3. Confusion matrix
im = axes[1,0].imshow(cm, interpolation='nearest', cmap='Blues')
axes[1,0].set_title(f'Confusion Matrix\n({best_name})', fontweight='bold')
axes[1,0].set_xlabel('Predicted')
axes[1,0].set_ylabel('Actual')
axes[1,0].set_xticks([0,1]); axes[1,0].set_yticks([0,1])
axes[1,0].set_xticklabels(['Retained','Churned']); axes[1,0].set_yticklabels(['Retained','Churned'])
for i in range(2):
    for j in range(2):
        axes[1,0].text(j, i, str(cm[i,j]), ha='center', va='center',
                       fontsize=16, fontweight='bold',
                       color='white' if cm[i,j] > cm.max()/2 else 'black')
plt.colorbar(im, ax=axes[1,0])

# 4. Feature importance
top_fi = perm_imp.head(10).sort_values('importance')
colors_fi = ['#e74c3c' if v > top_fi['importance'].median() else '#3498db' for v in top_fi['importance']]
axes[1,1].barh(range(len(top_fi)), top_fi['importance'], color=colors_fi, edgecolor='black', alpha=0.85)
axes[1,1].set_yticks(range(len(top_fi)))
axes[1,1].set_yticklabels(top_fi['feature'], fontsize=9)
axes[1,1].set_title('Top 10 Feature Importance\n(Permutation)', fontweight='bold')
axes[1,1].set_xlabel('Mean AUC Decrease')

plt.suptitle(f'Model Evaluation — Best: {best_name} (AUC={best_metrics["Test_AUC"]:.3f})',
             fontsize=13, fontweight='bold')
plt.tight_layout()
plt.savefig(FIGURE_PATH, dpi=150, bbox_inches='tight')
plt.close()
print(f"  ✓ Saved: {FIGURE_PATH}")

# ============================================================================
# SAVE MODEL & RESULTS
# ============================================================================

with open(MODEL_PATH, 'wb') as f:
    pickle.dump(best_model, f)
print(f"\n  ✓ Best model saved: {MODEL_PATH}")

comparison_df = pd.DataFrame([
    {'Model': name, **{k: v for k, v in met.items() if k not in ['test_proba','test_pred']}}
    for name, met in results.items()
]).sort_values('Test_AUC', ascending=False)
comparison_df.to_csv(COMPARISON_PATH, index=False)
print(f"  ✓ Model comparison: {COMPARISON_PATH}")

report = f"""PHASES 8-12: MODEL DEVELOPMENT SUMMARY
{'='*70}

INPUT:  {DATA_SELECTED}
OUTPUT: {MODEL_PATH}

DATA SPLIT:
  Train: {len(X_train):,} rows (60%)
  Val:   {len(X_val):,} rows  (20%)
  Test:  {len(X_test):,} rows  (20%)

MODELS TRAINED: {len(models)}

MODEL COMPARISON (sorted by Test AUC):
{comparison_df[['Model','Test_AUC','F1','Accuracy','Precision','Recall']].to_string(index=False)}

BEST MODEL: {best_name}
  Test AUC:    {best_metrics['Test_AUC']}
  Accuracy:    {best_metrics['Accuracy']}
  Precision:   {best_metrics['Precision']}
  Recall:      {best_metrics['Recall']}
  F1-Score:    {best_metrics['F1']}

CONFUSION MATRIX (Test Set):
  TN={cm[0,0]}  FP={cm[0,1]}
  FN={cm[1,0]}  TP={cm[1,1]}

TOP 5 FEATURES (Permutation Importance):
{perm_imp.head(5)[['feature','importance']].to_string(index=False)}

STATUS: ✓ Ready for Phase 13 (Business Insights)
"""
with open(REPORT_PATH, 'w') as f:
    f.write(report)
print(f"  ✓ Report: {REPORT_PATH}")

# ============================================================================
# COMPLETE
# ============================================================================

print("\n" + "=" * 70)
print(f"✓ PHASES 8-12 COMPLETE  |  Best: {best_name}  |  AUC: {best_metrics['Test_AUC']}")
print("=" * 70)
print(f"  Next: python scripts/13_business_insights.py")
