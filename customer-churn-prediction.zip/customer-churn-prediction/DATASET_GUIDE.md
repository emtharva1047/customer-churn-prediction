# Dataset Guide

## Overview

**Dataset**: IBM Telco Customer Churn
**Source**: Kaggle (https://www.kaggle.com/blastchar/telco-customer-churn)
**License**: CC0 (Public Domain)
**Size**: 7,043 rows × 21 columns
**Target Variable**: Churn (Yes/No)
**Positive Class**: 26.5%

---

## Download Instructions

### Option 1: Kaggle (Recommended)

1. **Visit Kaggle**
   - Go to: https://www.kaggle.com/blastchar/telco-customer-churn
   - Create account if needed (free)

2. **Download Dataset**
   - Click "Download" button
   - Accept terms if required
   - Save CSV file

3. **Place in Project**
   ```bash
   # Create directory if needed
   mkdir -p data/raw
   
   # Move file
   mv ~/Downloads/Telco-Customer-Churn.csv data/raw/
   
   # Verify
   ls -lh data/raw/Telco-Customer-Churn.csv
   ```

### Option 2: Command Line (Automated)

```bash
# Using wget (Linux/macOS)
wget https://raw.githubusercontent.com/IBM/telco-customer-churn-on-icp4d/master/data/Telco-Customer-Churn.csv -O data/raw/Telco-Customer-Churn.csv

# Using curl
curl -o data/raw/Telco-Customer-Churn.csv https://raw.githubusercontent.com/IBM/telco-customer-churn-on-icp4d/master/data/Telco-Customer-Churn.csv

# Verify download
ls -lh data/raw/Telco-Customer-Churn.csv  # Should be ~1 MB
```

### Option 3: Python Script

```python
import pandas as pd
import urllib.request
import os

# Create directory
os.makedirs('data/raw', exist_ok=True)

# Download
url = "https://raw.githubusercontent.com/IBM/telco-customer-churn-on-icp4d/master/data/Telco-Customer-Churn.csv"
filepath = "data/raw/Telco-Customer-Churn.csv"
urllib.request.urlretrieve(url, filepath)

# Verify
df = pd.read_csv(filepath)
print(f"✓ Dataset loaded: {df.shape}")
```

---

## Dataset Structure

### File Format
- **Format**: CSV (Comma-Separated Values)
- **Encoding**: UTF-8
- **Size**: ~1 MB
- **Rows**: 7,043 customer records
- **Columns**: 21 features

### Column Names and Types

| Column | Type | Description |
|--------|------|-------------|
| customerID | String | Unique customer identifier |
| gender | Categorical | Male/Female |
| SeniorCitizen | Binary | 1 if senior, 0 otherwise |
| Partner | Binary | Yes/No |
| Dependents | Binary | Yes/No |
| tenure | Numeric | Months with company |
| PhoneService | Binary | Yes/No |
| MultipleLines | Categorical | Yes/No/No phone service |
| InternetService | Categorical | DSL/Fiber optic/No |
| OnlineSecurity | Categorical | Yes/No/No internet service |
| OnlineBackup | Categorical | Yes/No/No internet service |
| DeviceProtection | Categorical | Yes/No/No internet service |
| TechSupport | Categorical | Yes/No/No internet service |
| StreamingTV | Categorical | Yes/No/No internet service |
| StreamingMovies | Categorical | Yes/No/No internet service |
| Contract | Categorical | Month-to-month/One year/Two year |
| PaperlessBilling | Binary | Yes/No |
| PaymentMethod | Categorical | Electronic check/Mailed check/Bank/Credit card |
| MonthlyCharges | Numeric | Monthly subscription amount |
| TotalCharges | Numeric/String | Total amount charged to customer |
| Churn | Binary | Yes/No (Target variable) |

### Data Quality Notes

1. **TotalCharges**: Stored as string (contains spaces)
   - Needs conversion to numeric
   - Some values may be missing or invalid

2. **Binary Features**: Mix of encoding
   - Some use "Yes"/"No"
   - SeniorCitizen uses 0/1
   - Need standardization

3. **Categorical Features**: Multiple encoding schemes
   - Some use "No internet service" as category
   - Others use different values
   - Requires careful handling

4. **Missing Values**:
   - Generally minimal
   - Check TotalCharges for new customers

---

## Exploratory Analysis

### Load and Explore
```python
import pandas as pd

# Load dataset
df = pd.read_csv('data/raw/Telco-Customer-Churn.csv')

# Basic info
print(f"Shape: {df.shape}")
print(f"Columns: {df.columns.tolist()}")

# Data types
print(df.dtypes)

# Missing values
print(df.isnull().sum())

# Target distribution
print(df['Churn'].value_counts())
print(df['Churn'].value_counts(normalize=True))  # Proportions
```

### Key Statistics
```
Dataset Shape: (7043, 21)

Churn Distribution:
- No:  5174 (73.5%)
- Yes: 1869 (26.5%)

Churn is imbalanced - class weight needed in modeling

Numeric Columns:
- tenure: 0-72 months
- MonthlyCharges: $18-$119
- TotalCharges: $0-$8685

Categorical Columns:
- Contract: 3 types
- PaymentMethod: 4 types
- InternetService: 3 types
```

---

## Data Preparation

### Step 1: Load Data
```python
import pandas as pd
df = pd.read_csv('data/raw/Telco-Customer-Churn.csv')
```

### Step 2: Check Data Quality
```python
# Check for missing values
print(df.isnull().sum())

# Check duplicates
print(f"Duplicates: {df.duplicated().sum()}")

# Check data types
print(df.dtypes)

# Check unique values
print(df.nunique())
```

### Step 3: Handle Issues
```python
# Remove unnecessary columns
df = df.drop('customerID', axis=1)

# Convert TotalCharges
df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce')
df['TotalCharges'].fillna(0, inplace=True)

# Standardize binary features
df['Churn'] = (df['Churn'] == 'Yes').astype(int)
df['Partner'] = (df['Partner'] == 'Yes').astype(int)
# ... continue for other binary features
```

### Step 4: Encoding
```python
# Categorical encoding
categorical_cols = df.select_dtypes(include=['object']).columns
df_encoded = pd.get_dummies(df, columns=categorical_cols, drop_first=True)

# Or use ordinal encoding for specific features
from sklearn.preprocessing import OrdinalEncoder
```

---

## Project Integration

### Expected File Location
```
Customer-Churn-Prediction/
└── data/
    └── raw/
        └── Telco-Customer-Churn.csv  ← Place here
```

### Project Scripts Reference
```
Script 03: Expects CSV in data/raw/Telco-Customer-Churn.csv
Script 04: Reads cleaned data, outputs Telco-Customer-Churn-Cleaned.csv
Script 05: Performs EDA, creates visualizations
Script 06: Handles missing data, creates features
...and so on
```

### Verification
```python
# Run this to verify dataset is in correct location
import os
import pandas as pd

filepath = 'data/raw/Telco-Customer-Churn.csv'

if os.path.exists(filepath):
    df = pd.read_csv(filepath)
    print(f"✓ Dataset found")
    print(f"✓ Shape: {df.shape}")
    print(f"✓ Columns: {df.columns.tolist()}")
else:
    print(f"✗ Dataset not found at {filepath}")
```

---

## Common Issues

### Issue: File Not Found
**Solution:**
```bash
# Verify file exists
ls -lh data/raw/Telco-Customer-Churn.csv

# Check file size (should be ~1 MB)
du -h data/raw/Telco-Customer-Churn.csv

# If missing, download again
wget https://raw.githubusercontent.com/IBM/telco-customer-churn-on-icp4d/master/data/Telco-Customer-Churn.csv -O data/raw/Telco-Customer-Churn.csv
```

### Issue: Encoding Error When Reading
**Solution:**
```python
# Try different encodings
df = pd.read_csv('data/raw/Telco-Customer-Churn.csv', encoding='utf-8')  # Default
df = pd.read_csv('data/raw/Telco-Customer-Churn.csv', encoding='latin-1')  # Alternative
df = pd.read_csv('data/raw/Telco-Customer-Churn.csv', encoding='iso-8859-1')  # Alternative
```

### Issue: TotalCharges Can't Convert
**Solution:**
```python
# Use errors='coerce' to handle invalid values
df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce')
df['TotalCharges'].fillna(0, inplace=True)
```

### Issue: Memory Error on Large Dataset
**Solution:**
```python
# Read in chunks
chunks = []
for chunk in pd.read_csv('data/raw/Telco-Customer-Churn.csv', chunksize=1000):
    chunks.append(chunk)
df = pd.concat(chunks)
```

---

## Data Notes for Modeling

### Class Imbalance
- Churn: 26.5% (minority class)
- Retained: 73.5% (majority class)
- **Solution**: Use `class_weight='balanced'` in models

### Feature Engineering Opportunities
- Customer lifetime value (from TotalCharges)
- Service adoption count (sum of internet services)
- Contract length categories
- Payment friction indicators

### Important Features (from EDA)
1. **Tenure**: Strongest predictor of churn
2. **Contract Type**: Major impact on churn
3. **Internet Service**: Quality issues in fiber
4. **Services Adopted**: More = lower churn
5. **Payment Method**: E-check = higher friction

---

## Next Steps

1. **Download Dataset**
   - Use one of the methods above
   - Place in `data/raw/`

2. **Verify Integrity**
   - Run the verification script
   - Check shape and columns

3. **Run First Script**
   ```bash
   python scripts/03_data_understanding.py
   ```

4. **Follow Guide**
   - Read: MASTER_EXECUTION_GUIDE.md
   - Execute: All scripts in sequence

---

**Ready?** Place your dataset and run: `python scripts/03_data_understanding.py`
